'''
This is a comment. It may span several lines.
The interpreter will ignore everything here,
including Python commands
'''
print("Explicit is _much_ better than implicit!") #this is also a comment
print()
print("NOW is better than *NEVER*.")
print("Although ")
print("never is often bet-ter than 'Right' now.")
