p0 = int(input())
r = float(input())
t = int(input())

num_germs = p0 * (1 + r) ** t
print(int(num_germs))
